class StoreController < ApplicationController
  def index
  end
end
