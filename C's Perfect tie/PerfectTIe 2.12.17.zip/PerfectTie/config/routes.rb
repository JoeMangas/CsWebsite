Rails.application.routes.draw do

  resources :products
  get 'register' => 'register#index'

  get 'login' => 'login#index'

  get 'contact' => 'contact#index'

  get 'store' => 'store#index'

  get 'home/index'
  
  root 'home#index'

  # For details on the DSL available within this file, see http://guides.rubyonrails.org/routing.html
end
