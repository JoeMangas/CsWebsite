require 'test_helper'

class PpageTest < ActiveSupport::TestCase
  # test "the truth" do
  #   assert true
  # end
end
