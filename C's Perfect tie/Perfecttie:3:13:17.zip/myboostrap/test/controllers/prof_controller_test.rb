require 'test_helper'

class ProfControllerTest < ActionDispatch::IntegrationTest
  test "should get new" do
    get prof_new_url
    assert_response :success
  end

end
