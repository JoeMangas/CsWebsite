class ItemsController < ApplicationController
  def index
  end
end
