class ProfController < ApplicationController
  def new
  end
end
