class Ppage < ApplicationRecord
end
