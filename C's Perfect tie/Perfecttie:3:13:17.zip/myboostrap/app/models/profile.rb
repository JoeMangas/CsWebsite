class Profile < ApplicationRecord
end
