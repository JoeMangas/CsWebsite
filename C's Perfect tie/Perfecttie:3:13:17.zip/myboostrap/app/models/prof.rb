class Prof < ApplicationRecord
end
