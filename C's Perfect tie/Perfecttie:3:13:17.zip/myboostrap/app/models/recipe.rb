class Recipe < ApplicationRecord
end
