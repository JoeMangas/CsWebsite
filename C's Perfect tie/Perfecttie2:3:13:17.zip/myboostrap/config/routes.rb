Rails.application.routes.draw do
  resources :ppages
  resources :tests
  resources :recipes
  resources :lists
  get 'prof/new'

  get 'users/new'

  resources :posts
  get 'profile/' => 'profile#index'

  get 'register' => 'register#index'

  get 'login' => 'login#index'

  get 'items' => 'items#index'

  get 'contact/index'

  get 'about' => 'about#index'

  get 'home/index'

  get 'ppages' => 'ppages#index'

root :to => "posts#index"
root 'home#index'
  # For details on the DSL available within this file, see http://guides.rubyonrails.org/routing.html
end
